import UIKit

/// Lets the user override the driver-license demo card: any photo, any name/number/dates.
/// Everything is stored locally only (see DemoProfileService) — nothing is sent anywhere.
final class DemoProfileEditViewController: UIViewController {

    private var profile: DemoProfile = DemoProfileService.shared.load()

    private let scrollView = UIScrollView()
    private let stackView = UIStackView()

    private let photoImageView = UIImageView()
    private let choosePhotoButton = UIButton(type: .system)

    private let fullNameField = DemoProfileEditViewController.makeField(placeholder: "ПІБ")
    private let birthdayField = DemoProfileEditViewController.makeField(placeholder: "Дата народження (дд.мм.рррр)")
    private let docNumberField = DemoProfileEditViewController.makeField(placeholder: "Серія та номер документа")
    private let categoryField = DemoProfileEditViewController.makeField(placeholder: "Категорії (напр. B, B1)")
    private let validUntilField = DemoProfileEditViewController.makeField(placeholder: "Дійсна до (дд.мм.рррр)")
    private let recordNumberField = DemoProfileEditViewController.makeField(placeholder: "Номер запису")

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Демо-профіль картки"
        view.backgroundColor = .systemBackground
        setupNavigationBar()
        setupLayout()
        fillFields(from: profile)
    }

    // MARK: - Setup

    private func setupNavigationBar() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Зберегти", style: .done, target: self, action: #selector(saveTapped))
    }

    private func setupLayout() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.addSubview(stackView)
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -20),
            stackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: -20),
            stackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor, constant: -40)
        ])

        photoImageView.contentMode = .scaleAspectFill
        photoImageView.clipsToBounds = true
        photoImageView.layer.cornerRadius = 12
        photoImageView.backgroundColor = .secondarySystemBackground
        photoImageView.translatesAutoresizingMaskIntoConstraints = false
        photoImageView.heightAnchor.constraint(equalToConstant: 160).isActive = true

        choosePhotoButton.setTitle("Обрати фото", for: .normal)
        choosePhotoButton.addTarget(self, action: #selector(choosePhotoTapped), for: .touchUpInside)

        [photoImageView, choosePhotoButton,
         fullNameField, birthdayField, docNumberField, categoryField, validUntilField, recordNumberField]
            .forEach { stackView.addArrangedSubview($0) }
    }

    private func fillFields(from profile: DemoProfile) {
        fullNameField.text = profile.fullName
        birthdayField.text = profile.birthday
        docNumberField.text = profile.docNumber
        categoryField.text = profile.category
        validUntilField.text = profile.validUntil
        recordNumberField.text = profile.recordNumber

        if let base64 = profile.photoBase64, let data = Data(base64Encoded: base64) {
            photoImageView.image = UIImage(data: data)
        }
    }

    // MARK: - Actions

    @objc private func choosePhotoTapped() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }

    @objc private func saveTapped() {
        view.endEditing(true)

        profile.fullName = fullNameField.text ?? profile.fullName
        profile.birthday = birthdayField.text ?? profile.birthday
        profile.docNumber = docNumberField.text ?? profile.docNumber
        profile.category = categoryField.text ?? profile.category
        profile.validUntil = validUntilField.text ?? profile.validUntil
        profile.recordNumber = recordNumberField.text ?? profile.recordNumber

        if let image = photoImageView.image, let base64 = DemoProfileEditViewController.base64(from: image) {
            profile.photoBase64 = base64
        }

        DemoProfileService.shared.save(profile)
        navigationController?.popViewController(animated: true)
    }

    // MARK: - Helpers

    private static func makeField(placeholder: String) -> UITextField {
        let field = UITextField()
        field.placeholder = placeholder
        field.borderStyle = .roundedRect
        field.heightAnchor.constraint(equalToConstant: 44).isActive = true
        return field
    }

    /// Downscales and JPEG-encodes the picked photo so it stays reasonably small in local storage.
    private static func base64(from image: UIImage) -> String? {
        let maxDimension: CGFloat = 800
        let scale = min(1, maxDimension / max(image.size.width, image.size.height))
        let targetSize = CGSize(width: image.size.width * scale, height: image.size.height * scale)

        let renderer = UIGraphicsImageRenderer(size: targetSize)
        let resized = renderer.image { _ in
            image.draw(in: CGRect(origin: .zero, size: targetSize))
        }
        return resized.jpegData(compressionQuality: 0.8)?.base64EncodedString()
    }
}

// MARK: - UIImagePickerControllerDelegate

extension DemoProfileEditViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let image = info[.originalImage] as? UIImage {
            photoImageView.image = image
        }
        picker.dismiss(animated: true)
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
}
