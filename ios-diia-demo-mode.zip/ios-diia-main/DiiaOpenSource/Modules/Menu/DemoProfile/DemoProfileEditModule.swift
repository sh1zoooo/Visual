import UIKit
import DiiaMVPModule

final class DemoProfileEditModule: BaseModule {
    private let view: DemoProfileEditViewController

    init() {
        view = DemoProfileEditViewController()
    }

    func viewController() -> UIViewController {
        return view
    }
}
