import UIKit
import DiiaUIComponents

struct SelectableIconTitleViewModel {
    let iconName: String
    let title: String
    let selectedIconName: String
}

class MainTabCollectionCell: BaseCollectionNibCell {
    
    // MARK: - Outlets
    @IBOutlet weak private var titleLabel: UILabel!
    @IBOutlet weak private var iconView: UIImageView!
    @IBOutlet weak private var iconViewHeightConstraint: NSLayoutConstraint!
    
    // MARK: - Properties
    private var vm: SelectableIconTitleViewModel?
    
    // MARK: - LifeCycle
    override func awakeFromNib() {
        super.awakeFromNib()
        
        titleLabel.font = FontBook.tabBarTitle
        iconViewHeightConstraint.constant = Constants.iconHeight
        setupAccessibility()
    }
    
    // MARK: - Public Methods
    func setSelected(isSelected: Bool) {
        guard let vm = vm else {
            return
        }
        let imageName = isSelected ? vm.selectedIconName : vm.iconName
        iconView.image = UIImage(named: imageName)
    }
    
    func configureAccessibility(isSelected: Bool, currentValue: Int, totalValue: Int, haveUnreadItem: Bool?) {
        guard let viewModel = vm else { return }
        self.accessibilityLabel = viewModel.title
        let haveUpdatesHint = haveUnreadItem ?? false ? "\(R.Strings.main_screen_accessibility_bottom_bar_cell_have_updates.localized()) " : ""
        self.accessibilityHint = haveUpdatesHint
    }
    
    func configure(with viewModel: SelectableIconTitleViewModel) {
        vm = viewModel
        titleLabel.setTextWithCurrentAttributes(text: viewModel.title)
        iconView.image = UIImage(named: viewModel.iconName)
    }
    
    // MARK: - Public Methods
    private func setupAccessibility() {
        self.isAccessibilityElement = true
        self.accessibilityTraits = .none
    }
}

// MARK: - Constants
extension MainTabCollectionCell {
    private enum Constants {
        static var iconHeight: CGFloat {
            switch UIScreen.main.bounds.width {
            case 414, 428, 430: return 26
            default: return 24
            }
        }
    }
}
