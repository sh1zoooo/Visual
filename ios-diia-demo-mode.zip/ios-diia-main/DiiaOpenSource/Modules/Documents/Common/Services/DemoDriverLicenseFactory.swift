import UIKit
import DiiaDocumentsCommonTypes
import DiiaUIComponents

/// Builds a `DSFullDocumentModel` for the driver-license document entirely from local data.
/// This mirrors the shape the real backend would send (frontCard.UA / frontCard.EN with
/// docHeadingOrg / tableBlockTwoColumnsPlaneOrg / tableBlockPlaneOrg), so it renders through
/// the same native `DSDocumentWithPhotoView` as the original app — just without any network call.
enum DemoDriverLicenseFactory {

    /// Regenerates the locally stored driver-license document from the given profile
    /// and saves it under the same key the real DocumentsLoader would use.
    static func regenerateStoredDocument(from profile: DemoProfile) {
        let doc = makeDriverLicenseDocument(from: profile)
        StoreHelper.instance.save(doc, type: DSFullDocumentModel.self, forKey: .driverLicense)
    }

    /// Ensures a document exists locally. Called on app start / documents refresh instead
    /// of a network request.
    static func ensureDocumentExists() {
        if let _: DSFullDocumentModel = StoreHelper.instance.getValue(forKey: .driverLicense) {
            return
        }
        regenerateStoredDocument(from: DemoProfileService.shared.load())
    }

    static func makeDriverLicenseDocument(from profile: DemoProfile) -> DSFullDocumentModel {
        let photoBase64 = profile.photoBase64 ?? Constants.placeholderPhotoBase64

        let docData = DSDocumentData(
            docStatus: DocumentStatusCode.ok.rawValue,
            id: Constants.documentId,
            qr: nil,
            docNumber: profile.docNumber,
            content: [DSDocumentContent(image: photoBase64, code: .photo)],
            docData: DSDocData(
                docName: Constants.title,
                birthday: profile.birthday,
                validUntil: profile.validUntil,
                fullName: profile.fullName,
                number: profile.recordNumber
            ),
            dataForDisplayingInOrderConfigurations: nil,
            dataForDisplayingAsListItem: nil,
            frontCard: DSDocumentFrontCard(
                UA: frontCard(profile: profile, title: Constants.title, birthdayLabel: "Дата народження", categoryLabel: "Категорії", validUntilLabel: "Дійсна до", numberLabel: "Номер запису"),
                EN: frontCard(profile: profile, title: "Driver's license", birthdayLabel: "Date of birth", categoryLabel: "Categories", validUntilLabel: "Valid until", numberLabel: "Record number")
            ),
            fullInfo: nil,
            shareLocalization: .ua,
            frontCardBackground: nil,
            cover: nil,
            additionalFullInfo: nil
        )

        return DSFullDocumentModel(
            status: .ok,
            expirationDate: Calendar.current.date(byAdding: .year, value: 10, to: Date()) ?? Date().addingTimeInterval(60 * 60 * 24 * 365 * 10),
            currentDate: Date(),
            data: [docData]
        )
    }

    private static func frontCard(profile: DemoProfile, title: String, birthdayLabel: String, categoryLabel: String, validUntilLabel: String, numberLabel: String) -> [DSDocumentModel] {
        return [
            DSDocumentModel(
                docHeadingOrg: DSDocumentHeading(
                    headingWithSubtitlesMlc: DSHeadingWithSubtitlesModel(value: title, subtitles: nil)
                )
            ),
            DSDocumentModel(
                tableBlockTwoColumnsPlaneOrg: DSTableBlockTwoColumnPlaneOrg(
                    photo: DSDocumentContentData.photo.rawValue,
                    items: [
                        DSItemsModel(tableItemVerticalMlc: DSTableItemVerticalMlc(label: nil, value: profile.fullName)),
                        DSItemsModel(tableItemVerticalMlc: DSTableItemVerticalMlc(label: categoryLabel, value: profile.category))
                    ],
                    headingWithSubtitlesMlc: nil
                )
            ),
            DSDocumentModel(
                tableBlockPlaneOrg: DSTableBlockItemModel(
                    tableMainHeadingMlc: nil,
                    tableSecondaryHeadingMlc: nil,
                    items: [
                        DSTableItem(tableItemHorizontalMlc: DSTableItemHorizontalMlc(label: birthdayLabel, value: profile.birthday)),
                        DSTableItem(tableItemHorizontalMlc: DSTableItemHorizontalMlc(label: validUntilLabel, value: profile.validUntil)),
                        DSTableItem(tableItemHorizontalMlc: DSTableItemHorizontalMlc(label: numberLabel, value: profile.recordNumber)),
                        DSTableItem(tableItemHorizontalMlc: DSTableItemHorizontalMlc(label: "Серія та номер", value: profile.docNumber))
                    ]
                )
            )
        ]
    }

    private enum Constants {
        static let documentId = "demo-driver-license"
        static let title = "Посвідчення водія"
        /// 1x1 transparent pixel — used only when the user hasn't picked a photo yet.
        static let placeholderPhotoBase64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
    }
}
