import UIKit

/// Editable data used to render the demo "driver license" card.
/// None of this data is sent anywhere — it only lives in local storage on the device.
struct DemoProfile: Codable, Equatable {
    var fullName: String
    var birthday: String       // dd.MM.yyyy
    var docNumber: String
    var category: String       // e.g. "B, B1"
    var validUntil: String     // dd.MM.yyyy
    var recordNumber: String
    var photoBase64: String?   // JPEG, base64-encoded

    static let `default` = DemoProfile(
        fullName: "ШЕВЧЕНКО ТАРАС ГРИГОРОВИЧ",
        birthday: "09.03.1990",
        docNumber: "SVB123456",
        category: "B, B1",
        validUntil: "09.03.2032",
        recordNumber: "12345678901",
        photoBase64: nil
    )
}

/// Local-only storage for the demo profile. Reading/writing here never touches the network.
final class DemoProfileService {
    static let shared = DemoProfileService()

    private let storeHelper: StoreHelperProtocol = StoreHelper.instance

    private init() {}

    func load() -> DemoProfile {
        return storeHelper.getValue(forKey: .demoProfile) ?? .default
    }

    /// Saves the profile and immediately regenerates the local driver-license document from it,
    /// so the change is reflected on the documents screen without any network round-trip.
    func save(_ profile: DemoProfile) {
        storeHelper.save(profile, type: DemoProfile.self, forKey: .demoProfile)
        DemoDriverLicenseFactory.regenerateStoredDocument(from: profile)
        NotificationCenter.default.post(name: AppConstants.Notifications.documentsWasReordered, object: nil)
    }
}
